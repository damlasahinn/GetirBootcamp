import UIKit

//Problem 4 Largest Palindrome Product

func isPalindrome(_ number: Int) -> Bool {
    let str = String(number)
    return str == String(str.reversed())
}

var largestPalindrome = 0
var a = 999
var b = 0
var product = 0

for i in stride(from: 999, to: 100, by: -1) {
    for j in stride(from: i, to: 100, by: -1) {
        product = i * j
        if product <= largestPalindrome {
            break
        }
        if isPalindrome(product) {
            largestPalindrome = product
            a = i
            b = j
        }
    }
}

print("Largest Palindrome \(largestPalindrome) = \(a) * \(b)")

//Problem 5 Smallest Multiple

func gcd(_ a:Int,_ b: Int) -> Int { //Greatest Common Divisior
    var a = a
    var b = b
    while b != 0 {
        let temp = b
        b = a % b
        a = temp
    }
    return a
}

func lcm(_ a: Int,_ b: Int) -> Int { //Least Common Multiple of two numbers
    return a / gcd(a, b) * b
}

func lcmRange(_ range: ClosedRange<Int>) -> Int {
    var result = 1
    for number in range {
        result = lcm(result,number)
    }
    
    return result
}

let result = lcmRange(1...20)
print("Result: ",result)

//Fonksiyona parametre olarak verilen sayıya göre + - karakterlerini ekrana yazdıran bir fonksiyon yaınız. Örneğin 1 için sadece +, 2 için +-, 5 için +-+-+ şeklinde olmalıdır

func printPlusMinus(_ number: Int) {
    var pattern = ""
    for i in 0..<number {
        if i % 2 == 0 {
            pattern += "+"
        } else {
            pattern += "-"
        }
    }
    print(pattern)
}

printPlusMinus(1)
printPlusMinus(2)
printPlusMinus(5)
printPlusMinus(7)

//Fonksiyona parametre olarak verilen sayıyı en büyük yapacak şekilde 5 sayısını ilgili basamağa koyunuz. // Örneğin parametre 0 için çıktı 50 olmalıdır. Parametre 28 için 528, parametre 920 için 9520 olmalıdır

func addFiveToMaximize(number: Int) -> Int {
    let isNegative = number < 0
    let numStr = String(abs(number))
    var bestNumber = isNegative ? Int.max : Int.min
    var bestStr = ""
    
    for i in 0...numStr.count {
        var newStr = numStr
        let index = newStr.index(newStr.startIndex, offsetBy: i)
        newStr.insert(contentsOf: "5", at: index)
        
        if let newNum = Int(newStr) {
            if isNegative {
                let negativeNewNum = -newNum
                if negativeNewNum > bestNumber {
                    bestNumber = negativeNewNum
                    bestStr = newStr
                }
            } else {
                if newNum > bestNumber {
                    bestNumber = newNum
                    bestStr = newStr
                }
            }
        }
    }

    return isNegative ? -Int(bestStr)! : Int(bestStr)!
}

// Örnek kullanımlar
print(addFiveToMaximize(number: 0))   // Çıktı: 50
print(addFiveToMaximize(number: 28))  // Çıktı: 528
print(addFiveToMaximize(number: 920)) // Çıktı: 9520


//Iki parametreli ve FARKLI tipli bir generic ornegi yapiniz (T, U)
func generics<T, U>(value1: T, value2: U) -> String {
    let str1 = String(describing: value1)
    let str2 = String(describing: value2)
    
    return str1 + " and " + str2
}

let result1 = generics(value1: 5, value2: "apples")
print(result1)

let result2 = generics(value1: true, value2: 3.14)
print(result2)

//Exercism 1 Vehichle Purchase

//Task 1 Compute whether or not you can afford the monthly payments on a given car
func canIBuy(vehicle: String, price: Double, monthlyBudget: Double) -> String {
    let numberOfMonths = 60.0 // 5 years in months
    let monthlyPayment = price / numberOfMonths

    if monthlyPayment <= monthlyBudget {
        return "Yes! I'm getting a \(vehicle)"
    } else if monthlyPayment <= monthlyBudget * 1.10 {
        return "I'll have to be frugal if I want a \(vehicle)"
    } else {
        return "Darn! No \(vehicle) for me"
    }
}
print(canIBuy(vehicle: "Hundai i20", price: 516.32, monthlyBudget: 100))

//Task 2 Determine the type of drivers license you will need
func licenseType(numberOfWheels wheels: Int) -> String {
    switch wheels {
    case 2, 3:
        return "You will need a motorcycle license for your vehicle"
    case 4, 6:
        return "You will need an automobile license for your vehicle"
    case 18:
        return "You will need a commercial trucking license for your vehicle"
    default:
        return "We do not issue licenses for those types of vehicles"
    }
}
licenseType(numberOfWheels: 2)
licenseType(numberOfWheels: 4)
licenseType(numberOfWheels: 18)
licenseType(numberOfWheels: 0)

//Task 3 Calculate an estimation for the price of a used vehicle
func calculateResellPrice(originalPrice: Int, yearsOld: Int) -> Int {
    if yearsOld < 3 {
        return Int(Double(originalPrice) * 0.8)
    } else if yearsOld < 10 {
        return Int(Double(originalPrice) * 0.7)
    } else {
        return Int(Double(originalPrice) * 0.5)
    }
}
calculateResellPrice(originalPrice: 1000, yearsOld: 1)
calculateResellPrice(originalPrice: 1000, yearsOld: 5)
calculateResellPrice(originalPrice: 1000, yearsOld: 15)

//Exercism 2 Freelancer Rates
//Task 1 Calculate the daily rate given an hourly rate
func dailyRateFrom(hourlyRate: Int) -> Double {
    return Double(hourlyRate) * 8.0
}

let dailyRate = dailyRateFrom(hourlyRate: 60)
print(dailyRate)

//Task 2 Calculate the monthly rate, given an hourly rate and a discount
func monthlyRateFrom(hourlyRate: Int, withDiscount discount: Double) -> Double {
    let dailyRate = Double(hourlyRate) * 8
    let monthlyRate = dailyRate * 22
    let discountedRate = monthlyRate * (1 - (discount / 100))
    let roundedRate = (discountedRate + 0.5).rounded(.down)
    return roundedRate
}
let monthlyRate = monthlyRateFrom(hourlyRate: 77, withDiscount: 10.5)
print(monthlyRate)

//Task 3 Calculate the number of workdays given a budget, hourly rate and discount
func workdaysIn(budget: Double, hourlyRate: Int, withDiscount discount: Double) -> Double {
    let discountedHourlyRate = Double(hourlyRate) * (1 - discount / 100)
    let totalHours = budget / discountedHourlyRate
    
    let workdays = totalHours / 8
    return floor(workdays)
}
let numberOfWorkdays = workdaysIn(budget: 20000, hourlyRate: 80, withDiscount: 11.0)
print(numberOfWorkdays)

//Exercism 3 Master Mixologist

//Task 1 Determine how long it takes to make an order
func timeToPrepare(drinks: [String]) -> Double {
    var totalTime = 0.0
    for drink in drinks {
        switch drink {
        case "beer", "soda", "water":
            totalTime += 0.5
        case "shot":
            totalTime += 1.0
        case "mixed drink":
            totalTime += 1.5
        case "fancy drink":
            totalTime += 2.5
        case "frozen drink":
            totalTime += 3.0
        default:
            break
        }
    }
    return totalTime
}

let preparationTime = timeToPrepare(drinks: ["beer", "frozen drink", "shot"])
print("Total preparation time: \(preparationTime)")

//Task 2 Replenish your lime wedge supply

func makeWedges(needed: Int, limes: [String]) -> Int {
    var totalWedges = 0
    var limesCut = 0
    for lime in limes where totalWedges < needed {
        switch lime {
        case "small":
            totalWedges += 6
        case "medium":
            totalWedges += 8
        case "large":
            totalWedges += 10
        default:
            break
        }
        limesCut += 1
    }
    return limesCut
}

let limesNeeded = makeWedges(needed: 25, limes: ["small", "small", "large", "medium", "small"])
print("Number of limes cut: \(limesNeeded)")
//Task 3 Track certain orders
func orderTracker(orders: [(drink: String, time: String)]) -> (beer: (first: String, last: String, total: Int)?, soda: (first: String, last: String, total: Int)?) {
    var beerTimes: [String] = []
    var sodaTimes: [String] = []
    
    for order in orders {
        switch order.drink {
        case "beer":
            beerTimes.append(order.time)
        case "soda":
            sodaTimes.append(order.time)
        default:
            break
        }
    }
    
    let beerInfo = !beerTimes.isEmpty ? (first: beerTimes.first!, last: beerTimes.last!, total: beerTimes.count) : nil
    let sodaInfo = !sodaTimes.isEmpty ? (first: sodaTimes.first!, last: sodaTimes.last!, total: sodaTimes.count) : nil
    
    return (beer: beerInfo, soda: sodaInfo)
}
let orderTimes = orderTracker(orders: [
    (drink: "beer", time: "10:01"),
    (drink: "frozen drink", time: "10:02"),
    (drink: "shot", time: "10:05"),
    (drink: "fancy drink", time: "10:06"),
    (drink: "soda", time: "10:09"),
    (drink: "beer", time: "10:15"),
    (drink: "beer", time: "10:22"),
    (drink: "water", time: "10:26"),
    (drink: "mixed drink", time: "10:28"),
    (drink: "frozen drink", time: "10:33")
])
print("Beer order times: \(String(describing: orderTimes.beer))")
print("Soda order times: \(String(describing: orderTimes.soda))")

//Exercism 4 Santas-Helper

//Task 1 Convert coordinates to polar

func cartesianToPolar(_ cart: (x: Double, y: Double)) -> (r: Double, phi: Double) {
    let r = sqrt(cart.x * cart.x + cart.y * cart.y)
    let phi = atan2(cart.y, cart.x)
    return (r, phi)
}

// Task 2: Merge two database records
func combineRecords(
  production: (toy: String, id: Int, productLead: String),
  gifts: (Int, [String])
) -> (id: Int, toy: String, productLead: String, recipients: [String]) {
 
  return (id: production.id, toy: production.toy, productLead: production.productLead, recipients: gifts.1)
}

let cartesianCoordinate = (x: -78.7542034870253, y: -39.24357377712724)
let polarCoordinate = cartesianToPolar(cartesianCoordinate)
print("Polar coordinate is r: \(polarCoordinate.r), phi: \(polarCoordinate.phi)")

let productionRecord = (toy: "Chemistry set", id: 32859, productLead: "Binkles")
let giftRecord = (32859, ["Inês", "Maxime", "Bandile", "Shaurya", "Екатерина"])
let combinedRecord = combineRecords(production: productionRecord, gifts: giftRecord)
print("Combined record: \(combinedRecord)")

//Exercism 5 Pizza slices

//Task 1 Write a function to compute slice sizes which return nil for invalide input
func sliceSize(diameter: Double?, slices: Int?) -> Double? {
    guard let diameter = diameter, let slices = slices, diameter > 0, slices > 0 else {
        return nil
    }
    let radius = diameter / 2
    let area = Double.pi * radius * radius
    return area / Double(slices)
}

// Task 2: Process input from your web application to determine the larger slice
func biggestSlice(
    diameterA: String, slicesA: String,
    diameterB: String, slicesB: String
) -> String {
    guard let diameterANum = Double(diameterA), let slicesANum = Int(slicesA),
          let diameterBNum = Double(diameterB), let slicesBNum = Int(slicesB) else {
        return "Invalid input"
    }
    
    if let sliceASize = sliceSize(diameter: diameterANum, slices: slicesANum),
       let sliceBSize = sliceSize(diameter: diameterBNum, slices: slicesBNum) {
        if sliceASize > sliceBSize {
            return "Slice A is bigger"
        } else if sliceBSize > sliceASize {
            return "Slice B is bigger"
        } else {
            return "Neither slice is bigger"
        }
    } else {
        return "One or both slices have invalid sizes"
    }
}

print(sliceSize(diameter: 16, slices: 12) ?? "Invalid input")
print(biggestSlice(diameterA: "16", slicesA: "8", diameterB: "18", slicesB: "8"))

//Exercism 6 Secret Handshake
//Convert a number between 1 and 31 to a sequence of actions in the secret handshake.

func commands(number: Int) -> [String] {
    let actions = ["wink", "double blink", "close your eyes", "jump"]
    
    let binary = String(number, radix: 2)
    let reversed = number >= 16
    
    var result = [String]()
    for (index, char) in binary.reversed().enumerated() {
        if index < actions.count && char == "1" {
            result.append(actions[index])
        }
    }
    
    return reversed ? result.reversed() : result
}

print(commands(number: 9))
print(commands(number: 19))
print(commands(number: 31))

//Exercism 7 Isogram
//Determine if a word or phrase is an isogram.

func isIsogram(_ string: String) -> Bool {
    let filteredString = string.lowercased().filter { $0.isLetter }
    let uniqueCharacters = Set(filteredString)
    return filteredString.count == uniqueCharacters.count
}

//Exercism 8 Pangram
//if a sentence is a pangram.

func isPangram(_ text: String) -> Bool {
    let lowercasedText = text.lowercased()
    let letters = Set(lowercasedText.filter { $0.isLetter })
    return letters.count == 26
}
print(isPangram("The quick brown fox jumps over the lazy dog."))

//Exercism 9 Pascal Triangle
//Compute Pascal's triangle up to a given number of rows.

func pascalsTriangle(rows: Int) -> [[Int]] {
    var triangle = [[Int]]()
    
    for row in 0..<rows {
        var newRow = [Int](repeating: 0, count: row + 1)
        newRow[0] = 1
        newRow[row] = 1
        
        if row > 1 {
            for col in 1..<row {
                newRow[col] = triangle[row-1][col-1] + triangle[row-1][col]
            }
        }
        
        triangle.append(newRow)
    }
    
    return triangle
}
print(pascalsTriangle(rows: 5))

//Exercism 10 Prime Factors
//Compute the prime factors of a given natural number.

func primeFactors(of number: Int64) -> [Int64] {
    var n = number
    var factors: [Int64] = []
    var divisor: Int64 = 2

    while n > 1 {
        while n % divisor == 0 {
            factors.append(divisor)
            n /= divisor
        }
        divisor += divisor == 2 ? 1 : 2
    }

    return factors
}
let factors = primeFactors(of: 60)
print(factors)

