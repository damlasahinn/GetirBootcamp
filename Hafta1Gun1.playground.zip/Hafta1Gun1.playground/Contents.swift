import UIKit

//Problem 1 Multiples of 3 or 5

var sum = 0

for number in 1..<1000 {
    if number % 3 == 0 || number % 5 == 0 {
        sum += number
    }
}

print("Sum: ", sum)

// Problem 2 Even Fibonacci Numbers

var sumEven = 0
var first = 1
var second = 2

while second <= 4000000 {
    if second % 2 == 0 {
        sumEven += second
    }
    
    var  next = first + second
    first = second
    second = next
}

print("Sum of the even-valued: ",sumEven)

// Problem 3 Largest Prime Factor

var number = 600851475143
var largestPrimeFactor = 2

while number > 1 {
    if number % largestPrimeFactor == 0 {
        number /= largestPrimeFactor
    } else {
        largestPrimeFactor += 1
    }
}
print("Largest prime factor is: ", largestPrimeFactor)

// Elimizde sadece harflerden oluşan (noktalama işareti veya sayılar yok) uzun stringler olsun. Bu stringler içinde bazı harflerin tekrar edeceğini düşünün. Mesela 'a' harfi 20 farklı yerde geçiyor olabilir. Bir fonksiyon ile verilen parametre değerine eşit ve daha fazla bulunan harfleri siliniz.Sonra geriye kalan stringi ekrana yazdırınız.  ----

func removeCharacters(_ inputString: String, repeatLimit: Int) -> String {
    var characterCounts: [Character: Int] = [:]
    
    for character in inputString {
        if character.isLetter {
            characterCounts[character, default: 0] += 1
        }
    }
    
    let result = inputString.filter { character in
        if let count = characterCounts[character], count >= repeatLimit {
            return false
        }
        return true
    }
    return result
}

let testStr = "aaba kouq bux"
print("Tekrar 2: ", removeCharacters(testStr, repeatLimit: 2))
print("Tekrar 3: ", removeCharacters(testStr, repeatLimit: 3))
print("Tekrar 4: ", removeCharacters(testStr, repeatLimit: 4))


// Elimizde uzun bir cümle olsun. Bazı kelimelerin tekrar ettiği bir cümle düşünün. İstediğimiz ise, hangi kelimeden kaç tane kullanıldığını bulmak.
//String = "Merhaba nasılsınız iyiyim siz nasılsınız bende iyiyim"
//Merhaba 1 kere, nasılsınız 2 kere iyiyim 2 kere

func countWordFrequency(_ sentence: String) -> [String: Int] {
    let words = sentence.split(separator: " ").map(String.init)
    
    var frequencyDict = [String: Int]()
    
    for word in words {
        let currentCount = frequencyDict[word, default: 0]
        frequencyDict[word] = currentCount + 1
    }
    
    return frequencyDict
}

let sentence = "Merhaba nasılsınız iyiyim siz nasılsınız bende iyiyim"
let wordFrequency = countWordFrequency(sentence)

for(word, frequency) in wordFrequency {
    print("\(word) \(frequency) kere")
}

//*** Hashable protokolü setler için neden avantaj sağlar? ***//
/* Hashable protokolü bir nesnenin hash değerini oluşturulmasını ve kullanılmasını sağlar. Set koleksiyonları benzersiz öğelerin hızlı bir şekilde saklanmasını ve yönetilmesini sağlar.
Avantajlar:
 -Eşsizlik: Her öğrenin benzersiz hash değeri olması, Set içindeki öğelerin benzersiz kalmasını sağlar
 -Hızlı Erişim ve Arama: Hash değerleri üzerinde yapılan aramalar, öğelere hızlı erişim sağlar
 -Performans: İyi tasarlanmış hash mekanizmaları, Set işlemlerini verimli hale getirir.
 -Karşılaştırma: Hash değerlerini karşılaştırmak, Öğelerin hızlı bir şekilde karşılaştırılmasını sağlar.
 Özellikle büyük ve benzersiz öğe koleksiyonlarını yönetirken, Hashable protokolü sayesinde yüksek performans ve verimlilik elde edilir.
*/
